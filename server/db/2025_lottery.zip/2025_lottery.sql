/*
 Navicat Premium Data Transfer

 Source Server         : localhost_27017
 Source Server Type    : MongoDB
 Source Server Version : 80003
 Source Host           : localhost:27017
 Source Schema         : 2025_lottery

 Target Server Type    : MongoDB
 Target Server Version : 80003
 File Encoding         : 65001

 Date: 04/12/2025 23:37:17
*/


// ----------------------------
// Collection structure for adminMenus
// ----------------------------
db.getCollection("adminMenus").drop();
db.createCollection("adminMenus");

// ----------------------------
// Documents of adminMenus
// ----------------------------
db.getCollection("adminMenus").insert([ {
    _id: ObjectId("693063263b1573ac078769a5"),
    name: "ACL",
    link: "#",
    "parent_id": "",
    weight: NumberInt("1"),
    "is_dashboard": false,
    icon: "fa-shield",
    status: true
} ]);
db.getCollection("adminMenus").insert([ {
    _id: ObjectId("693063263b1573ac078769a6"),
    name: "Admin Users",
    link: "admin/users",
    "parent_id": "693063263b1573ac078769a5",
    weight: NumberInt("0"),
    "is_dashboard": true,
    icon: "fa-users",
    status: true
} ]);
db.getCollection("adminMenus").insert([ {
    _id: ObjectId("693063263b1573ac078769a7"),
    name: "Modules",
    link: "admin/modules",
    "parent_id": "693063263b1573ac078769a5",
    weight: NumberInt("1"),
    "is_dashboard": true,
    icon: "fa-th-large",
    status: true
} ]);
db.getCollection("adminMenus").insert([ {
    _id: ObjectId("693063263b1573ac078769a8"),
    name: "Resources",
    link: "admin/resources",
    "parent_id": "693063263b1573ac078769a5",
    weight: NumberInt("1"),
    "is_dashboard": true,
    icon: "fa-database",
    status: true
} ]);
db.getCollection("adminMenus").insert([ {
    _id: ObjectId("693063263b1573ac078769a9"),
    name: "Permissions",
    link: "admin/permissions",
    "parent_id": "693063263b1573ac078769a5",
    weight: NumberInt("1"),
    "is_dashboard": true,
    icon: "fa-lock",
    status: true
} ]);
db.getCollection("adminMenus").insert([ {
    _id: ObjectId("693063263b1573ac078769aa"),
    name: "Roles",
    link: "admin/roles",
    "parent_id": "693063263b1573ac078769a5",
    weight: NumberInt("1"),
    "is_dashboard": true,
    icon: "fa-check-square-o",
    status: true
} ]);
db.getCollection("adminMenus").insert([ {
    _id: ObjectId("693063263b1573ac078769ab"),
    name: "Custom fields",
    link: "admin/custom_fields",
    "parent_id": "693063263b1573ac078769a5",
    weight: NumberInt("1"),
    "is_dashboard": true,
    icon: "fa-sliders",
    status: true
} ]);
db.getCollection("adminMenus").insert([ {
    _id: ObjectId("693063263b1573ac078769ac"),
    name: "Menus",
    link: "admin/menus",
    "parent_id": "",
    weight: NumberInt("1"),
    "is_dashboard": true,
    icon: "fa-list-ul",
    status: true
} ]);
db.getCollection("adminMenus").insert([ {
    _id: ObjectId("693063263b1573ac078769ad"),
    name: "Settings",
    link: "admin/settings",
    "parent_id": "",
    weight: NumberInt("1"),
    "is_dashboard": true,
    icon: "fa-cog",
    status: true
} ]);
db.getCollection("adminMenus").insert([ {
    _id: ObjectId("693063263b1573ac078769ae"),
    name: "Tools",
    link: "admin/tools",
    "parent_id": "",
    weight: NumberInt("1"),
    "is_dashboard": true,
    icon: "fa-wrench",
    status: true
} ]);
db.getCollection("adminMenus").insert([ {
    _id: ObjectId("693063ac3cd4fc0fbcddcfdb"),
    link: "logs/acd",
    name: "logs_acd",
    "parent_id": "",
    weight: NumberInt("1"),
    icon: "fa-circle-o",
    "is_dashboard": false,
    status: true,
    createdAt: ISODate("2025-12-03T16:22:04.097Z"),
    updatedAt: ISODate("2025-12-03T16:22:04.097Z"),
    __v: NumberInt("0")
} ]);
db.getCollection("adminMenus").insert([ {
    _id: ObjectId("693063ac3cd4fc0fbcddcfe0"),
    link: "logs/cp_log",
    name: "logs_cp_log",
    "parent_id": "",
    weight: NumberInt("1"),
    icon: "fa-circle-o",
    "is_dashboard": false,
    status: true,
    createdAt: ISODate("2025-12-03T16:22:04.116Z"),
    updatedAt: ISODate("2025-12-03T16:22:04.116Z"),
    __v: NumberInt("0")
} ]);
db.getCollection("adminMenus").insert([ {
    _id: ObjectId("693068cc41594b914b2697d5"),
    link: "lucky/user",
    name: "lucky_user",
    "parent_id": "",
    weight: NumberInt("1"),
    icon: "fa-circle-o",
    "is_dashboard": false,
    status: true,
    createdAt: ISODate("2025-12-03T16:43:56.844Z"),
    updatedAt: ISODate("2025-12-03T16:43:56.844Z"),
    __v: NumberInt("0")
} ]);
db.getCollection("adminMenus").insert([ {
    _id: ObjectId("693069fe41594b914b2697db"),
    link: "lucky/bet",
    name: "lucky_bet",
    "parent_id": "",
    weight: NumberInt("1"),
    icon: "fa-circle-o",
    "is_dashboard": false,
    status: true,
    createdAt: ISODate("2025-12-03T16:49:02.842Z"),
    updatedAt: ISODate("2025-12-03T16:49:02.842Z"),
    __v: NumberInt("0")
} ]);
db.getCollection("adminMenus").insert([ {
    _id: ObjectId("69306a8c41594b914b2697e1"),
    link: "lucky/publisher",
    name: "lucky_publisher",
    "parent_id": "",
    weight: NumberInt("1"),
    icon: "fa-circle-o",
    "is_dashboard": false,
    status: true,
    createdAt: ISODate("2025-12-03T16:51:24.57Z"),
    updatedAt: ISODate("2025-12-03T16:51:24.57Z"),
    __v: NumberInt("0")
} ]);
db.getCollection("adminMenus").insert([ {
    _id: ObjectId("69306b4341594b914b2697e7"),
    link: "lucky/schedule",
    name: "lucky_schedule",
    "parent_id": "",
    weight: NumberInt("1"),
    icon: "fa-circle-o",
    "is_dashboard": false,
    status: true,
    createdAt: ISODate("2025-12-03T16:54:27.547Z"),
    updatedAt: ISODate("2025-12-03T16:54:27.547Z"),
    __v: NumberInt("0")
} ]);

// ----------------------------
// Collection structure for adminModules
// ----------------------------
db.getCollection("adminModules").drop();
db.createCollection("adminModules");

// ----------------------------
// Documents of adminModules
// ----------------------------
db.getCollection("adminModules").insert([ {
    _id: ObjectId("693063263b1573ac07876991"),
    name: "admin",
    route: "admin",
    status: true
} ]);
db.getCollection("adminModules").insert([ {
    _id: ObjectId("693063ac3cd4fc0fbcddcfd6"),
    name: "logs",
    route: "logs",
    status: true,
    createdAt: ISODate("2025-12-03T16:22:04.072Z"),
    updatedAt: ISODate("2025-12-03T16:22:04.072Z"),
    __v: NumberInt("0")
} ]);
db.getCollection("adminModules").insert([ {
    _id: ObjectId("693068cc41594b914b2697d1"),
    name: "lucky",
    route: "lucky",
    status: true,
    createdAt: ISODate("2025-12-03T16:43:56.822Z"),
    updatedAt: ISODate("2025-12-03T16:43:56.822Z"),
    __v: NumberInt("0")
} ]);

// ----------------------------
// Collection structure for adminPermissions
// ----------------------------
db.getCollection("adminPermissions").drop();
db.createCollection("adminPermissions");

// ----------------------------
// Documents of adminPermissions
// ----------------------------
db.getCollection("adminPermissions").insert([ {
    _id: ObjectId("693063263b1573ac078769a2"),
    role: "manager",
    module: "admin",
    resource: "dashboard",
    permissions: [
        "view",
        "update-profile"
    ]
} ]);
db.getCollection("adminPermissions").insert([ {
    _id: ObjectId("693063263b1573ac078769a3"),
    role: "admin",
    module: "admin",
    resource: "dashboard",
    permissions: [
        "view",
        "update-profile"
    ]
} ]);
db.getCollection("adminPermissions").insert([ {
    _id: ObjectId("693063263b1573ac078769a4"),
    role: "guest",
    module: "admin",
    resource: "dashboard",
    permissions: [
        "view",
        "update-profile"
    ]
} ]);

// ----------------------------
// Collection structure for adminResources
// ----------------------------
db.getCollection("adminResources").drop();
db.createCollection("adminResources");

// ----------------------------
// Documents of adminResources
// ----------------------------
db.getCollection("adminResources").insert([ {
    _id: ObjectId("693063263b1573ac07876998"),
    name: "dashboard",
    module: "admin",
    "collection_name": "",
    permissions: [
        "view",
        "update-profile"
    ]
} ]);
db.getCollection("adminResources").insert([ {
    _id: ObjectId("693063263b1573ac07876999"),
    name: "users",
    module: "admin",
    permissions: [
        "view",
        "detail",
        "add",
        "edit",
        "delete",
        "import",
        "export"
    ],
    "collection_name": "adminUsers",
    "default_fields": [ ]
} ]);
db.getCollection("adminResources").insert([ {
    _id: ObjectId("693063263b1573ac0787699a"),
    name: "modules",
    module: "admin",
    permissions: [
        "view",
        "detail",
        "add",
        "edit",
        "delete",
        "import",
        "export"
    ],
    "collection_name": "adminModules",
    "default_fields": [ ]
} ]);
db.getCollection("adminResources").insert([ {
    _id: ObjectId("693063263b1573ac0787699b"),
    name: "resources",
    module: "admin",
    permissions: [
        "view",
        "detail",
        "add",
        "edit",
        "delete",
        "import",
        "export"
    ],
    "collection_name": "adminResources",
    "default_fields": [ ]
} ]);
db.getCollection("adminResources").insert([ {
    _id: ObjectId("693063263b1573ac0787699c"),
    module: "admin",
    name: "permissions",
    permissions: [
        "view",
        "detail",
        "add",
        "edit",
        "delete",
        "import",
        "export"
    ],
    "collection_name": "adminPermissions",
    "default_fields": [ ]
} ]);
db.getCollection("adminResources").insert([ {
    _id: ObjectId("693063263b1573ac0787699d"),
    module: "admin",
    name: "roles",
    permissions: [
        "view",
        "detail",
        "add",
        "edit",
        "delete",
        "import",
        "export"
    ],
    "collection_name": "adminRoles",
    "default_fields": [ ]
} ]);
db.getCollection("adminResources").insert([ {
    _id: ObjectId("693063263b1573ac0787699e"),
    module: "admin",
    name: "menus",
    permissions: [
        "view",
        "detail",
        "add",
        "edit",
        "delete",
        "import",
        "export"
    ],
    "collection_name": "adminMenus",
    "default_fields": [ ]
} ]);
db.getCollection("adminResources").insert([ {
    _id: ObjectId("693063263b1573ac0787699f"),
    module: "admin",
    name: "settings",
    permissions: [
        "view",
        "detail",
        "add",
        "edit",
        "delete",
        "import",
        "export"
    ],
    "collection_name": "adminSettings",
    "default_fields": [ ]
} ]);
db.getCollection("adminResources").insert([ {
    _id: ObjectId("693063263b1573ac078769a0"),
    module: "admin",
    name: "custom_fields",
    permissions: [
        "view",
        "detail",
        "add",
        "edit",
        "delete",
        "import",
        "export"
    ],
    "collection_name": "adminCustomFields",
    "default_fields": [ ]
} ]);
db.getCollection("adminResources").insert([ {
    _id: ObjectId("693063263b1573ac078769a1"),
    module: "admin",
    name: "tools",
    permissions: [
        "view"
    ],
    "collection_name": "",
    "default_fields": [ ]
} ]);
db.getCollection("adminResources").insert([ {
    _id: ObjectId("693063ac3cd4fc0fbcddcfe5"),
    name: "acd",
    module: "logs",
    "collection_name": "",
    "default_fields": [ ],
    permissions: [
        "view",
        "detail",
        "add",
        "edit",
        "delete",
        "import",
        "export",
        "report"
    ],
    createdAt: ISODate("2025-12-03T16:22:04.132Z"),
    updatedAt: ISODate("2025-12-03T16:22:04.132Z"),
    __v: NumberInt("0")
} ]);
db.getCollection("adminResources").insert([ {
    _id: ObjectId("693063ac3cd4fc0fbcddcfea"),
    name: "cp_log",
    module: "logs",
    "collection_name": "",
    "default_fields": [ ],
    permissions: [
        "view",
        "detail",
        "add",
        "edit",
        "delete",
        "import",
        "export",
        "report"
    ],
    createdAt: ISODate("2025-12-03T16:22:04.147Z"),
    updatedAt: ISODate("2025-12-03T16:22:04.147Z"),
    __v: NumberInt("0")
} ]);
db.getCollection("adminResources").insert([ {
    _id: ObjectId("693068cc41594b914b2697d3"),
    name: "user",
    module: "lucky",
    "collection_name": "lk_users",
    "default_fields": [ ],
    permissions: [
        "view",
        "detail",
        "add",
        "edit",
        "delete",
        "import",
        "export",
        "report"
    ],
    createdAt: ISODate("2025-12-03T16:43:56.836Z"),
    updatedAt: ISODate("2025-12-03T16:43:56.836Z"),
    __v: NumberInt("0")
} ]);
db.getCollection("adminResources").insert([ {
    _id: ObjectId("693069fe41594b914b2697d9"),
    name: "bet",
    module: "lucky",
    "collection_name": "lk_bets",
    "default_fields": [ ],
    permissions: [
        "view",
        "detail",
        "add",
        "edit",
        "delete",
        "import",
        "export",
        "report"
    ],
    createdAt: ISODate("2025-12-03T16:49:02.834Z"),
    updatedAt: ISODate("2025-12-03T16:49:02.834Z"),
    __v: NumberInt("0")
} ]);
db.getCollection("adminResources").insert([ {
    _id: ObjectId("69306a8c41594b914b2697df"),
    name: "publisher",
    module: "lucky",
    "collection_name": "lk_publishers",
    "default_fields": [ ],
    permissions: [
        "view",
        "detail",
        "add",
        "edit",
        "delete",
        "import",
        "export",
        "report"
    ],
    createdAt: ISODate("2025-12-03T16:51:24.562Z"),
    updatedAt: ISODate("2025-12-03T16:51:24.562Z"),
    __v: NumberInt("0")
} ]);
db.getCollection("adminResources").insert([ {
    _id: ObjectId("69306b4341594b914b2697e5"),
    name: "schedule",
    module: "lucky",
    "collection_name": "lk_schedules",
    "default_fields": [ ],
    permissions: [
        "view",
        "detail",
        "add",
        "edit",
        "delete",
        "import",
        "export",
        "report"
    ],
    createdAt: ISODate("2025-12-03T16:54:27.541Z"),
    updatedAt: ISODate("2025-12-03T16:54:27.541Z"),
    __v: NumberInt("0")
} ]);

// ----------------------------
// Collection structure for adminRoles
// ----------------------------
db.getCollection("adminRoles").drop();
db.createCollection("adminRoles");

// ----------------------------
// Documents of adminRoles
// ----------------------------
db.getCollection("adminRoles").insert([ {
    _id: ObjectId("693063263b1573ac07876992"),
    role: "root",
    name: "Root",
    status: NumberInt("1"),
    weight: NumberInt("100")
} ]);
db.getCollection("adminRoles").insert([ {
    _id: ObjectId("693063263b1573ac07876993"),
    role: "qc",
    name: "QC",
    status: NumberInt("1"),
    weight: NumberInt("99")
} ]);
db.getCollection("adminRoles").insert([ {
    _id: ObjectId("693063263b1573ac07876994"),
    role: "manager",
    name: "Manager",
    status: NumberInt("1"),
    weight: NumberInt("9")
} ]);
db.getCollection("adminRoles").insert([ {
    _id: ObjectId("693063263b1573ac07876995"),
    role: "admin",
    name: "Admin",
    status: NumberInt("1"),
    weight: NumberInt("8")
} ]);
db.getCollection("adminRoles").insert([ {
    _id: ObjectId("693063263b1573ac07876996"),
    role: "sale",
    name: "Sale",
    status: NumberInt("1"),
    weight: NumberInt("7")
} ]);
db.getCollection("adminRoles").insert([ {
    _id: ObjectId("693063263b1573ac07876997"),
    role: "guest",
    name: "Guest",
    status: NumberInt("1"),
    weight: NumberInt("0")
} ]);

// ----------------------------
// Collection structure for adminSettings
// ----------------------------
db.getCollection("adminSettings").drop();
db.createCollection("adminSettings");

// ----------------------------
// Documents of adminSettings
// ----------------------------
db.getCollection("adminSettings").insert([ {
    _id: ObjectId("693063263b1573ac078769af"),
    key: "language",
    value: "en",
    "is_system": NumberInt("1"),
    description: ""
} ]);
db.getCollection("adminSettings").insert([ {
    _id: ObjectId("693063263b1573ac078769b0"),
    key: "menu_layout",
    value: "left",
    "is_system": NumberInt("1"),
    description: ""
} ]);
db.getCollection("adminSettings").insert([ {
    _id: ObjectId("693063263b1573ac078769b1"),
    key: "grid_limit",
    value: NumberInt("20"),
    "is_system": NumberInt("1"),
    description: ""
} ]);

// ----------------------------
// Collection structure for adminUsers
// ----------------------------
db.getCollection("adminUsers").drop();
db.createCollection("adminUsers");

// ----------------------------
// Documents of adminUsers
// ----------------------------
db.getCollection("adminUsers").insert([ {
    _id: ObjectId("693063263b1573ac07876990"),
    username: "lottery",
    password: "$2b$09$adlRe24ym.pPKwLZ4myavOj5Z6/VXkc9.SoXww6PKxDUsRX6YfMkS",
    fullname: "lottery",
    avatar: "public/admin/images/avatar/default.jpg",
    role: "root",
    status: NumberInt("1"),
    is2FAEnabled: true,
    secret2FA: "H4JVICBKDMGA6AK5",
    updatedAt: ISODate("2025-12-04T15:50:27.703Z"),
    "login_incorrect": NumberInt("0"),
    "login_time": 1764863427700
} ]);

// ----------------------------
// Collection structure for lk_publishers
// ----------------------------
db.getCollection("lk_publishers").drop();
db.createCollection("lk_publishers");

// ----------------------------
// Documents of lk_publishers
// ----------------------------
db.getCollection("lk_publishers").insert([ {
    _id: ObjectId("6931ae40c58efa8fc1238a87"),
    name: "TP. HCM",
    slug: "xshcm",
    description: "xshcm",
    date: [
        "MONDAY",
        "SATURDAY"
    ],
    periods: [
        NumberInt("1"),
        NumberInt("6")
    ],
    status: NumberInt("1"),
    weight: NumberInt("1"),
    "update_by": "lottery",
    createdAt: ISODate("2025-12-04T15:52:32.033Z"),
    updatedAt: ISODate("2025-12-04T16:28:43.426Z"),
    __v: NumberInt("0"),
    type: NumberInt("1")
} ]);
db.getCollection("lk_publishers").insert([ {
    _id: ObjectId("6931b1d8e98311e104702c44"),
    name: "Đồng Tháp",
    slug: "xsdt",
    description: "xsdt",
    date: [
        "MONDAY"
    ],
    periods: [
        NumberInt("1")
    ],
    status: NumberInt("1"),
    weight: NumberInt("1"),
    "update_by": "lottery",
    createdAt: ISODate("2025-12-04T16:07:52.679Z"),
    updatedAt: ISODate("2025-12-04T16:07:52.679Z"),
    __v: NumberInt("0"),
    type: 2
} ]);
db.getCollection("lk_publishers").insert([ {
    _id: ObjectId("6931b20be98311e104702c4a"),
    name: "Cà Mau",
    slug: "xscm",
    description: "xscm",
    date: [
        "MONDAY"
    ],
    periods: [
        NumberInt("1")
    ],
    status: NumberInt("1"),
    weight: NumberInt("1"),
    "update_by": "lottery",
    createdAt: ISODate("2025-12-04T16:08:43.389Z"),
    updatedAt: ISODate("2025-12-04T16:08:43.389Z"),
    __v: NumberInt("0"),
    type: 3
} ]);
db.getCollection("lk_publishers").insert([ {
    _id: ObjectId("6931b236e98311e104702c50"),
    name: "Bến Tre",
    slug: "xsbt",
    description: "xsbt",
    date: [
        "TUESDAY"
    ],
    periods: [
        NumberInt("2")
    ],
    status: NumberInt("1"),
    weight: NumberInt("1"),
    "update_by": "lottery",
    createdAt: ISODate("2025-12-04T16:09:26.633Z"),
    updatedAt: ISODate("2025-12-04T16:09:26.633Z"),
    __v: NumberInt("0"),
    type: 1
} ]);
db.getCollection("lk_publishers").insert([ {
    _id: ObjectId("6931b259e98311e104702c56"),
    name: "Vũng Tàu",
    slug: "xsvt",
    description: "xsvt",
    date: [
        "TUESDAY"
    ],
    periods: [
        NumberInt("2")
    ],
    status: NumberInt("1"),
    weight: NumberInt("1"),
    "update_by": "lottery",
    createdAt: ISODate("2025-12-04T16:10:01.216Z"),
    updatedAt: ISODate("2025-12-04T16:10:01.216Z"),
    __v: NumberInt("0"),
    type: 2
} ]);
db.getCollection("lk_publishers").insert([ {
    _id: ObjectId("6931b28ae98311e104702c5c"),
    name: "Bạc Liêu",
    slug: "xsbl",
    description: "Bạc Liêu",
    date: [
        "TUESDAY"
    ],
    periods: [
        NumberInt("2")
    ],
    status: NumberInt("1"),
    weight: NumberInt("1"),
    "update_by": "lottery",
    createdAt: ISODate("2025-12-04T16:10:50.153Z"),
    updatedAt: ISODate("2025-12-04T16:10:50.153Z"),
    __v: NumberInt("0"),
    type: 3
} ]);
db.getCollection("lk_publishers").insert([ {
    _id: ObjectId("6931b2b3e98311e104702c62"),
    name: "Đồng Nai",
    slug: "xsdn",
    description: "Đồng Nai",
    date: [
        "WEDNESDAY"
    ],
    periods: [
        NumberInt("3")
    ],
    status: NumberInt("1"),
    weight: NumberInt("1"),
    "update_by": "lottery",
    createdAt: ISODate("2025-12-04T16:11:31.591Z"),
    updatedAt: ISODate("2025-12-04T16:11:31.591Z"),
    __v: NumberInt("0"),
    type: 1
} ]);
db.getCollection("lk_publishers").insert([ {
    _id: ObjectId("6931b3a2e98311e104702c68"),
    name: "Cần Thơ",
    slug: "xsct",
    description: "Cần Thơ",
    date: [
        "WEDNESDAY"
    ],
    periods: [
        NumberInt("3")
    ],
    status: NumberInt("1"),
    weight: NumberInt("1"),
    "update_by": "lottery",
    createdAt: ISODate("2025-12-04T16:15:30.514Z"),
    updatedAt: ISODate("2025-12-04T16:15:30.514Z"),
    __v: NumberInt("0"),
    type: 2
} ]);
db.getCollection("lk_publishers").insert([ {
    _id: ObjectId("6931b3cce98311e104702c6e"),
    name: "Sóc Trăng",
    slug: "xsst",
    description: "Sóc Trăng",
    date: [
        "WEDNESDAY"
    ],
    periods: [
        NumberInt("3")
    ],
    status: NumberInt("1"),
    weight: NumberInt("1"),
    "update_by": "lottery",
    createdAt: ISODate("2025-12-04T16:16:12.746Z"),
    updatedAt: ISODate("2025-12-04T16:16:12.746Z"),
    __v: NumberInt("0"),
    type: 3
} ]);
db.getCollection("lk_publishers").insert([ {
    _id: ObjectId("6931b455e98311e104702c74"),
    name: "Tây Ninh",
    slug: "xstn",
    description: "Tây Ninh",
    date: [
        "THURSDAY"
    ],
    periods: [
        NumberInt("4")
    ],
    status: NumberInt("1"),
    weight: NumberInt("1"),
    "update_by": "lottery",
    createdAt: ISODate("2025-12-04T16:18:29.558Z"),
    updatedAt: ISODate("2025-12-04T16:18:29.558Z"),
    __v: NumberInt("0"),
    type: 1
} ]);
db.getCollection("lk_publishers").insert([ {
    _id: ObjectId("6931b475e98311e104702c7a"),
    name: "An Giang",
    slug: "xsag",
    description: "An Giang",
    date: [
        "THURSDAY"
    ],
    periods: [
        NumberInt("4")
    ],
    status: NumberInt("1"),
    weight: NumberInt("1"),
    "update_by": "lottery",
    createdAt: ISODate("2025-12-04T16:19:01.103Z"),
    updatedAt: ISODate("2025-12-04T16:19:01.103Z"),
    __v: NumberInt("0"),
    type: 2
} ]);
db.getCollection("lk_publishers").insert([ {
    _id: ObjectId("6931b4a9e98311e104702c80"),
    name: "Bình Thuận",
    slug: "xsbth",
    description: "Bình Thuận",
    date: [
        "THURSDAY"
    ],
    periods: [
        NumberInt("4")
    ],
    status: NumberInt("1"),
    weight: NumberInt("1"),
    "update_by": "lottery",
    createdAt: ISODate("2025-12-04T16:19:53.394Z"),
    updatedAt: ISODate("2025-12-04T16:19:53.394Z"),
    __v: NumberInt("0"),
    type: 3
} ]);
db.getCollection("lk_publishers").insert([ {
    _id: ObjectId("6931b4d2e98311e104702c86"),
    name: "Vĩnh Long",
    slug: "xsvl",
    description: "Vĩnh Long",
    date: [
        "FRIDAY"
    ],
    periods: [
        NumberInt("5")
    ],
    status: NumberInt("1"),
    weight: NumberInt("1"),
    "update_by": "lottery",
    createdAt: ISODate("2025-12-04T16:20:34.971Z"),
    updatedAt: ISODate("2025-12-04T16:20:34.971Z"),
    __v: NumberInt("0"),
    type: 1
} ]);
db.getCollection("lk_publishers").insert([ {
    _id: ObjectId("6931b4f4e98311e104702c8c"),
    name: "Bình Dương",
    slug: "xsbd",
    description: "Bình Dương",
    date: [
        "FRIDAY"
    ],
    periods: [
        NumberInt("5")
    ],
    status: NumberInt("1"),
    weight: NumberInt("1"),
    "update_by": "lottery",
    createdAt: ISODate("2025-12-04T16:21:08.591Z"),
    updatedAt: ISODate("2025-12-04T16:21:08.591Z"),
    __v: NumberInt("0"),
    type: 2
} ]);
db.getCollection("lk_publishers").insert([ {
    _id: ObjectId("6931b547e98311e104702c92"),
    name: "Trà Vinh",
    slug: "xstv",
    description: "Trà Vinh",
    date: [
        "FRIDAY"
    ],
    periods: [
        NumberInt("5")
    ],
    status: NumberInt("1"),
    weight: NumberInt("1"),
    "update_by": "lottery",
    createdAt: ISODate("2025-12-04T16:22:31.618Z"),
    updatedAt: ISODate("2025-12-04T16:22:31.618Z"),
    __v: NumberInt("0"),
    type: 3
} ]);
db.getCollection("lk_publishers").insert([ {
    _id: ObjectId("6931b57de98311e104702c98"),
    name: "Long An",
    slug: "xsla",
    description: "Long An",
    date: [
        "SATURDAY"
    ],
    periods: [
        NumberInt("6")
    ],
    status: NumberInt("1"),
    weight: NumberInt("1"),
    "update_by": "lottery",
    createdAt: ISODate("2025-12-04T16:23:25.324Z"),
    updatedAt: ISODate("2025-12-04T16:23:25.324Z"),
    __v: NumberInt("0"),
    type: 2
} ]);
db.getCollection("lk_publishers").insert([ {
    _id: ObjectId("6931b598e98311e104702c9e"),
    name: "Bình Phước",
    slug: "xsbp",
    description: "Bình Phước",
    date: [
        "SATURDAY"
    ],
    periods: [
        NumberInt("6")
    ],
    status: NumberInt("1"),
    weight: NumberInt("1"),
    "update_by": "lottery",
    createdAt: ISODate("2025-12-04T16:23:52.816Z"),
    updatedAt: ISODate("2025-12-04T16:23:52.816Z"),
    __v: NumberInt("0"),
    type: 3
} ]);
db.getCollection("lk_publishers").insert([ {
    _id: ObjectId("6931b5b3e98311e104702ca4"),
    name: "Hậu Giang",
    slug: "xshg",
    description: "Hậu Giang",
    date: [
        "SATURDAY"
    ],
    periods: [
        NumberInt("6")
    ],
    status: NumberInt("1"),
    weight: NumberInt("1"),
    "update_by": "lottery",
    createdAt: ISODate("2025-12-04T16:24:19.214Z"),
    updatedAt: ISODate("2025-12-04T16:24:19.214Z"),
    __v: NumberInt("0"),
    type: 4
} ]);
db.getCollection("lk_publishers").insert([ {
    _id: ObjectId("6931b5dbe98311e104702caa"),
    name: "Tiền Giang",
    slug: "xstg",
    description: "Tiền Giang",
    date: [
        "SUNDAY"
    ],
    periods: [
        NumberInt("0")
    ],
    status: NumberInt("1"),
    weight: NumberInt("1"),
    "update_by": "lottery",
    createdAt: ISODate("2025-12-04T16:24:59.773Z"),
    updatedAt: ISODate("2025-12-04T16:24:59.773Z"),
    __v: NumberInt("0"),
    type: 1
} ]);
db.getCollection("lk_publishers").insert([ {
    _id: ObjectId("6931b5ffe98311e104702cb0"),
    name: "Kiên Giang",
    slug: "xskg",
    description: "Kiên Giang",
    date: [
        "SUNDAY"
    ],
    periods: [
        NumberInt("0")
    ],
    status: NumberInt("1"),
    weight: NumberInt("1"),
    "update_by": "lottery",
    createdAt: ISODate("2025-12-04T16:25:35.267Z"),
    updatedAt: ISODate("2025-12-04T16:25:35.267Z"),
    __v: NumberInt("0"),
    type: 2
} ]);
db.getCollection("lk_publishers").insert([ {
    _id: ObjectId("6931b61de98311e104702cb6"),
    name: "Đà Lạt",
    slug: "xsdl",
    description: "Đà Lạt",
    date: [
        "SUNDAY"
    ],
    periods: [
        NumberInt("0")
    ],
    status: NumberInt("1"),
    weight: NumberInt("1"),
    "update_by": "lottery",
    createdAt: ISODate("2025-12-04T16:26:05.029Z"),
    updatedAt: ISODate("2025-12-04T16:26:05.029Z"),
    __v: NumberInt("0"),
    type: 3
} ]);
